/*
 author Anastasiya
 created on 05/08/2021
 */

package com.example.anycliptest.service;

import com.example.anycliptest.model.GeneralStatistics;


public interface StatisticsReceiver {
    GeneralStatistics getStatistics();

}
